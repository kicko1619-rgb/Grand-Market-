# GRAND MARKET

A no-checkout marketplace with:
- Public approved product listings
- Seller submission form
- Cloudinary image uploads
- MongoDB Atlas shared database
- Password-only admin panel
- Admin approval/rejection/deletion
- Responsive modern UI

## 1. Install

```bash
npm install
```

## 2. Configure

Copy `.env.example` to `.env` and fill in:
- MONGODB_URI
- ADMIN_PASSWORD
- JWT_SECRET
- CLOUDINARY_CLOUD_NAME
- CLOUDINARY_API_KEY
- CLOUDINARY_API_SECRET

## 3. MongoDB Atlas

Create a free cluster, create a database user, and put the connection string in `MONGODB_URI`.
For testing, add your current IP in Atlas Network Access. For a deployed Render service, use Atlas's appropriate network access configuration.

## 4. Cloudinary

Create an account and copy the cloud name, API key and API secret into `.env`.

## 5. Run

```bash
npm start
```

Open:
- Marketplace: `http://localhost:3000`
- Admin: `http://localhost:3000/admin/`

## 6. Deploy

Deploy the project as a Node web service on Render.
Add all `.env` values as Render Environment Variables.

IMPORTANT:
- Never commit `.env`.
- Use a long random ADMIN_PASSWORD.
- Use a long random JWT_SECRET.
- This project intentionally has no buyer checkout/payment flow.
