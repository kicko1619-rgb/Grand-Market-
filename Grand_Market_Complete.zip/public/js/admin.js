const login = document.querySelector("#login");
const panel = document.querySelector("#panel");
const loginForm = document.querySelector("#loginForm");
const loginMsg = document.querySelector("#loginMsg");
const grid = document.querySelector("#adminGrid");
const count = document.querySelector("#count");

let token = localStorage.getItem("lm_admin_token");

function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function showPanel(){login.hidden=true;panel.hidden=false;load();}
function showLogin(){login.hidden=false;panel.hidden=true;}

async function load(){
  const res=await fetch("/api/admin/listings",{headers:{Authorization:`Bearer ${token}`}});
  if(res.status===401){localStorage.removeItem("lm_admin_token");token=null;showLogin();return;}
  const data=await res.json();
  count.textContent=`${data.length} total`;
  grid.innerHTML=data.map(x=>`
    <article class="admin-card">
      <img src="${esc(x.imageUrl)}" alt="${esc(x.name)}">
      <div class="body">
        <span class="badge ${x.status}">${esc(x.status)}</span>
        <h3>${esc(x.name)}</h3>
        <strong>₹${Number(x.price).toLocaleString("en-IN")}</strong>
        <p>${esc(x.description)}</p>
        <div class="meta">Discord: ${esc(x.discord)}</div>
        <div class="actions">
          ${x.status!=="approved"?`<button class="action approve" onclick="act('${x._id}','approve')">Approve</button>`:""}
          ${x.status!=="rejected"?`<button class="action reject" onclick="act('${x._id}','reject')">Reject</button>`:""}
          <button class="action delete" onclick="removeItem('${x._id}')">Delete</button>
        </div>
      </div>
    </article>
  `).join("");
}

window.act=async(id,type)=>{
  const res=await fetch(`/api/admin/listings/${id}/${type}`,{
    method:"PATCH",headers:{Authorization:`Bearer ${token}`}
  });
  if(res.ok) load(); else alert("Action failed");
};

window.removeItem=async id=>{
  if(!confirm("Delete this listing permanently?"))return;
  const res=await fetch(`/api/admin/listings/${id}`,{
    method:"DELETE",headers:{Authorization:`Bearer ${token}`}
  });
  if(res.ok) load(); else alert("Delete failed");
};

loginForm.addEventListener("submit",async e=>{
  e.preventDefault();
  loginMsg.textContent="Checking...";
  const res=await fetch("/api/admin/login",{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({password:document.querySelector("#password").value})
  });
  const data=await res.json();
  if(!res.ok){loginMsg.textContent=data.message||"Wrong password";return;}
  token=data.token;localStorage.setItem("lm_admin_token",token);showPanel();
});

document.querySelector("#refresh").onclick=load;
document.querySelector("#logout").onclick=()=>{localStorage.removeItem("lm_admin_token");token=null;showLogin();};
if(token)showPanel();
