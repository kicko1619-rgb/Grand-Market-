const grid = document.querySelector("#grid");
const statusBox = document.querySelector("#status");
const search = document.querySelector("#search");
const form = document.querySelector("#listingForm");
const formMsg = document.querySelector("#formMsg");

let listings = [];

function money(n) {
  return new Intl.NumberFormat("en-IN", { style:"currency", currency:"INR", maximumFractionDigits:2 }).format(n);
}

function render() {
  const q = search.value.trim().toLowerCase();
  const data = listings.filter(x =>
    x.name.toLowerCase().includes(q) || x.description.toLowerCase().includes(q)
  );

  statusBox.textContent = data.length ? `${data.length} listing${data.length === 1 ? "" : "s"}` : "No listings found";
  grid.innerHTML = data.map(x => `
    <article class="card">
      <img src="${escapeHtml(x.imageUrl)}" alt="${escapeHtml(x.name)}" loading="lazy">
      <div class="card-body">
        <h3>${escapeHtml(x.name)}</h3>
        <div class="price">${money(x.price)}</div>
        <p class="desc">${escapeHtml(x.description)}</p>
        <div class="discord">💬 Discord: ${escapeHtml(x.discord)}</div>
      </div>
    </article>
  `).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function loadListings() {
  try {
    const res = await fetch("/api/listings");
    if (!res.ok) throw new Error("Failed");
    listings = await res.json();
    render();
  } catch {
    statusBox.textContent = "Could not load listings.";
  }
}

search.addEventListener("input", render);

form.addEventListener("submit", async e => {
  e.preventDefault();
  const button = form.querySelector("button");
  button.disabled = true;
  button.textContent = "Uploading...";
  formMsg.textContent = "";

  try {
    const res = await fetch("/api/listings", {
      method: "POST",
      body: new FormData(form)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Submission failed");

    form.reset();
    formMsg.textContent = "✓ Submitted! Your product will appear after admin approval.";
  } catch (err) {
    formMsg.textContent = "✕ " + err.message;
  } finally {
    button.disabled = false;
    button.textContent = "Submit for approval";
  }
});

loadListings();
