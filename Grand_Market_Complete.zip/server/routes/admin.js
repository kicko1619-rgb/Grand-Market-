import express from "express";
import jwt from "jsonwebtoken";
import Listing from "../models/Listing.js";
import { requireAdmin } from "../middleware/adminAuth.js";
import { deleteImage } from "../cloudinary.js";

const router = express.Router();

router.post("/login", (req, res) => {
  const { password } = req.body;

  if (!password || password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ message: "Wrong password" });
  }

  const token = jwt.sign({ role: "admin" }, process.env.JWT_SECRET, { expiresIn: "12h" });
  res.json({ token });
});

router.get("/listings", requireAdmin, async (req, res) => {
  const listings = await Listing.find().sort({ createdAt: -1 });
  res.json(listings);
});

router.patch("/listings/:id/approve", requireAdmin, async (req, res) => {
  const item = await Listing.findByIdAndUpdate(
    req.params.id,
    { status: "approved" },
    { new: true }
  );
  if (!item) return res.status(404).json({ message: "Listing not found" });
  res.json(item);
});

router.patch("/listings/:id/reject", requireAdmin, async (req, res) => {
  const item = await Listing.findByIdAndUpdate(
    req.params.id,
    { status: "rejected" },
    { new: true }
  );
  if (!item) return res.status(404).json({ message: "Listing not found" });
  res.json(item);
});

router.delete("/listings/:id", requireAdmin, async (req, res) => {
  const item = await Listing.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ message: "Listing not found" });

  if (item.imagePublicId) {
    try { await deleteImage(item.imagePublicId); } catch {}
  }

  res.json({ message: "Listing deleted" });
});

export default router;
