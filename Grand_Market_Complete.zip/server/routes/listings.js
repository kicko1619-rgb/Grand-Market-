import express from "express";
import multer from "multer";
import Listing from "../models/Listing.js";
import { uploadImage } from "../cloudinary.js";

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Only image files are allowed"));
    }
    cb(null, true);
  }
});

router.get("/", async (req, res) => {
  const listings = await Listing.find({ status: "approved" })
    .sort({ createdAt: -1 })
    .select("-imagePublicId");
  res.json(listings);
});

router.post("/", upload.single("image"), async (req, res) => {
  try {
    const { name, price, description, discord } = req.body;

    if (!name || !price || !description || !discord || !req.file) {
      return res.status(400).json({ message: "All fields and an image are required" });
    }

    const numericPrice = Number(price);
    if (!Number.isFinite(numericPrice) || numericPrice < 0) {
      return res.status(400).json({ message: "Invalid price" });
    }

    const uploaded = await uploadImage(req.file.buffer);

    const listing = await Listing.create({
      name,
      price: numericPrice,
      description,
      discord,
      imageUrl: uploaded.secure_url,
      imagePublicId: uploaded.public_id,
      status: "pending"
    });

    res.status(201).json({
      message: "Listing submitted for admin approval",
      id: listing._id
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message || "Upload failed" });
  }
});

export default router;
